from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import KMeans

app = Flask(__name__)

# Load dataset
movies = pd.read_csv("dataset.csv")
movies["genre"].fillna("", inplace=True)
movies["overview"].fillna("", inplace=True)
movies["tags"] = movies["overview"] + " " + movies["genre"]

# Preprocess
cv = CountVectorizer(max_features=10000, stop_words="english")
vector = cv.fit_transform(movies["tags"].values.astype("U")).toarray()
similarity = cosine_similarity(vector)

# Clustering (Optional)
num_clusters = 5
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
movies["cluster"] = kmeans.fit_predict(similarity)


@app.route("/recommend", methods=["POST"])
def recommend_movies():
    try:
        data = request.json
        movie_names = data.get("movies", [])

        recommendations = {}
        for movie_name in movie_names:
            try:
                movie_idx = movies[movies["title"] == movie_name].index[0]
                sim_scores = list(enumerate(similarity[movie_idx]))
                sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
                top_similar = sim_scores[1:11]
                recommended_titles = [movies.iloc[i[0]].title for i in top_similar]
                recommendations[movie_name] = recommended_titles
            except IndexError:
                recommendations[movie_name] = [
                    "Movie not found. Please check the movie name."
                ]

        return jsonify(recommendations)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
