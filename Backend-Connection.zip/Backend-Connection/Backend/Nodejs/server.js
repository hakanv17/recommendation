const express = require('express');
const axios = require('axios');
const app = express();

// Python API URL
const PYTHON_API_URL = 'http://localhost:5000/recommend';

// Endpoint to get recommendations from Python API
app.get('/api/recommend', async (req, res) => {
    try {
        const movie = req.query.movie;
        if (!movie) {
            return res.status(400).json({ error: "Movie query parameter is required." });
        }

        // Send request to Python API
        const response = await axios.get(`${PYTHON_API_URL}?movie=${encodeURIComponent(movie)}`);
        
        // Log the Python response data to the terminal
        console.log("Python API response:", response.data);
        
        res.json(response.data);
    } catch (error) {
        console.error('Error communicating with Python API:', error.message);
        res.status(500).json({ error: "Failed to get recommendations." });
    }
});

// Endpoint to get recommendations from Python API
app.post('/api/recommend', async (req, res) => {
    try {
        const movie = req.query.movie;  // Parametreyi body olarak gönderiyoruz
        if (!movie) {
            return res.status(400).json({ error: "Movie query parameter is required." });
        }

        // Send request to Python API
        const response = await axios.post(PYTHON_API_URL, { movies: [movie] }); // POST isteği gönderiyoruz
        res.json(response.data);
    } catch (error) {
        console.error('Error communicating with Python API:', error.message);
        res.status(500).json({ error: "Failed to get recommendations." });
    }
});


const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Node.js server running on http://localhost:${PORT}`);
});
